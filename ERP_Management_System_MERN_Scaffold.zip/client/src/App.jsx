export default function App(){return <h1>ERP Management System</h1>}
