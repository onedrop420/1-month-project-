# ERP Management System (MERN)

Project scaffold generated from the provided specification.

## Tech
- React
- Node.js
- Express
- MongoDB
- JWT Authentication

## Modules
- Users
- Products
- Customers
- Suppliers
- Sales Orders
- Purchase Orders
- GRN
- Invoices
